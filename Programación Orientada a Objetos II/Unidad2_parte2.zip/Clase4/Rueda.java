package Clase4;

public interface Rueda {

    public void avanzar();
    public void rebotar();
    public void desinflar();
    public void inflar();
    public void desgastar();
    public void detenerse();
}
