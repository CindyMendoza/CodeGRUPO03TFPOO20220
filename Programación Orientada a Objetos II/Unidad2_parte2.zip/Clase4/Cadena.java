package Clase4;

public interface Cadena {

    public void engrasar();

}
