package Taller2.Interfaces;

public class LenguajeProgramacion implements Lenguaje{

    @Override
    public void mostrarDatos() {
        System.out.println("Hola, soy el lenguaje de programación Java.");
    }

}
