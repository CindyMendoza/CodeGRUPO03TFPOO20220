package Repaso;

import java.util.List;

public class Main {
    public static void main(String[] args) {

        //B:
        //Voy a crear 3 vehiculos: ...motorees y ...llantas
        //Motores
        Motor motor1 = new Motor("MT001", 20);
        Motor motor2 = new Motor("MT002", 15);
        Motor motor3 = new Motor("MT001", 18);

        Llanta llantaA = new Llanta("Pirelli", "Normal");
        Llanta llantaB = new Llanta("GoodYear", "Deportivo");
        Llanta llantaC = new Llanta("Dunlop", "Normal");

        Llanta[] llantasA = {llantaA, llantaA, llantaA, llantaA};
        Vehiculo vehiculo1 = new Vehiculo("Toyota", "Camry", motor1, llantasA);

        Llanta[] llantasB = {llantaB, llantaB, llantaB, llantaB};
        Vehiculo vehiculo2 = new Vehiculo("Hyundai", "Elantra", motor2, llantasB);

        Llanta[] llantasC = {llantaC, llantaC, llantaC, llantaC};
        Vehiculo vehiculo3 = new Vehiculo("Honda", "Civic", motor3, llantasC);

        //C
        Tienda tienda = new Tienda();
        tienda.registrarVehiculo(vehiculo1);
        tienda.registrarVehiculo(vehiculo2);
        tienda.registrarVehiculo(vehiculo3);

        //D
        System.out.println("Listado de todos los vehículos de la tienda");
        List<Vehiculo> vehiculosRegistradosTienda = tienda.getVehiculos();
        for (Vehiculo vehiculo: vehiculosRegistradosTienda){
            System.out.println(vehiculo.getMarca() + " - " + vehiculo.getModelo() + " - " + vehiculo.getMotor().getModelo());
        }

        //E
        System.out.println("Listado de vehículos con modelo de motor específico");
        List<Vehiculo> vehiculosModeloMotor = tienda.listarVehiculosModeloMotor("MT002");
        for (Vehiculo vehiculo: vehiculosModeloMotor){
            System.out.println(vehiculo.getMarca() + " - " + vehiculo.getModelo() + " - " + vehiculo.getMotor().getModelo());
        }
    }
}
