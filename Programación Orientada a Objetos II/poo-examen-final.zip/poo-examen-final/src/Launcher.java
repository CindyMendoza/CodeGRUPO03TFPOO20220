import com.renzocastro.examenfinal.App;

public class Launcher {
  public static void main(String[] args) {
    new App();
  }
}
