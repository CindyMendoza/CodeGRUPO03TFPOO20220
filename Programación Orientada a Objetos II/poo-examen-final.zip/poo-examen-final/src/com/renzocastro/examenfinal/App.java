package com.renzocastro.examenfinal;

import com.renzocastro.examenfinal.models.TrabajadorDestacado;
import com.renzocastro.examenfinal.models.TrabajadorNombrado;
import com.renzocastro.examenfinal.models.TrabajadorTemporal;
import com.renzocastro.examenfinal.modules.empresa.EmpresaController;
import com.renzocastro.examenfinal.modules.empresa.EmpresaView;
import com.renzocastro.examenfinal.services.DataModelService;
import com.renzocastro.examenfinal.shared.Utils;
import com.renzocastro.examenfinal.shared.enums.Categorizacion;
import com.renzocastro.examenfinal.shared.exceptions.DataModelException;

public class App {

  DataModelService dataModel;

  public App() {
    Utils.setUtilidadesProyectadas(500000.0);

    this.dataModel = new DataModelService();

    // b) Registre al menos 6 trabajadores, 2 de cada tipo. (2 puntos)
    this.llenadoDeDatos();

    EmpresaController controlador = new EmpresaController(new EmpresaView(), dataModel.getTrabajadores());

    // c) Desarrolle un método que liste todos los trabajadores registrados
    //    y que muestre todos sus atributos y sueldo final (2 puntos)
    controlador.listarTrabajadores();

    // d) Desarrolle un método que obtenga el monto total que la empresa paga
    //    a los trabajadores temporales (2 puntos)
    controlador.mostrarPagoTotalATrabajadoresTemporales();

    // e) Desarrolle una excepción que no permita ingresar los datos de un trabajador
    //    cuyo número de DNI está previamente registrado. (2 puntos).
    this.agregarTrabajadorConDniRepetido();
  }

  public void llenadoDeDatos() {
    try {
      this.dataModel.addTrabajador(new TrabajadorNombrado(
        "42428383",
        "Carlos Diaz Gonzales",
        "Prolg. Andahuaylas 673, La Victoria",
        "Marketing Digital",
        4500.0,
        Categorizacion.A
      ));
      this.dataModel.addTrabajador(new TrabajadorNombrado(
        "42537654",
        "Diana Rivas Castro",
        "Calle las begonias 123, Miraflores",
        "Marketing Digital",
        3200.0,
        Categorizacion.B
      ));
      this.dataModel.addTrabajador(new TrabajadorTemporal(
        "41345678",
        "Alberto Alarcon Tapia",
        "Av. Los aires 456, San Luis",
        "UI/UX",
        80.0,
        50
      ));
      this.dataModel.addTrabajador(new TrabajadorTemporal(
        "41987687",
        "Barbara Ferrua Dazo",
        "Jr. Los andes 1234, La Molina",
        "UI/UX",
        40.0,
        70
      ));
      this.dataModel.addTrabajador(new TrabajadorDestacado(
        "42455433",
        "Diego Mori Lu",
        "Av. Cánada 1744, San Borja",
        "TI",
        5000.0,
        1.5
      ));
      this.dataModel.addTrabajador(new TrabajadorDestacado(
        "43434343",
        "Carlos Cifuentes Gallo",
        "Av. Huaylas 1034, Chorrillos",
        "TI",
        7000.0,
        1.0
      ));
    } catch (DataModelException dataModelEx) {
      System.out.println(dataModelEx.getMessage());
    }
  }

  public void agregarTrabajadorConDniRepetido() {
    try {
      this.dataModel.addTrabajador(new TrabajadorNombrado(
        "42428383", // <-- DNI Repetido
        "Maria Segura Chu",
        "Av. La Paz 567, Miraflores",
        "TI",
        1500.0,
        Categorizacion.C
      ));
    } catch (DataModelException dataModelEx) {
      System.out.println("DataModelException: " + dataModelEx.getMessage() + ".");
    }
  }
}
