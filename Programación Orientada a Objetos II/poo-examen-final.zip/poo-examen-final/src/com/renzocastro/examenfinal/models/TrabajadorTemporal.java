package com.renzocastro.examenfinal.models;

public class TrabajadorTemporal extends TrabajadorAbstract {
  private double tarifaPorHora;
  private int horasDeTrabajo;

  public TrabajadorTemporal(String dni, String nombreCompleto, String direccion, String areaDeTrabajo, double tarifaPorHora, int horasDeTrabajo) {
    super(dni, nombreCompleto, direccion, areaDeTrabajo);
    this.tarifaPorHora = tarifaPorHora;
    this.horasDeTrabajo = horasDeTrabajo;
  }

  public double getTarifaPorHora() {
    return tarifaPorHora;
  }

  public void setTarifaPorHora(double tarifaPorHora) {
    this.tarifaPorHora = tarifaPorHora;
  }

  public int getHorasDeTrabajo() {
    return horasDeTrabajo;
  }

  public void setHorasDeTrabajo(int horasDeTrabajo) {
    this.horasDeTrabajo = horasDeTrabajo;
  }

  @Override
  public double calcularSueldoFinal() {
    return this.getHorasDeTrabajo() * this.getTarifaPorHora();
  }

  @Override
  public String toString() {
    return "TrabajadorTemporal{" +
      "DNI='" + this.getDni() + '\'' +
      ", Nombre completo='" + this.getNombreCompleto() + '\'' +
      ", Direccion='" + this.getDireccion() + '\'' +
      ", Área de trabajo='" + this.getAreaDeTrabajo() + '\'' +
      ", Tarifa por hora=" + this.getTarifaPorHora() +
      ", Horas de trabajo=" + this.getHorasDeTrabajo() +
      ", Sueldo final=" + this.calcularSueldoFinal() +
      '}';
  }
}
