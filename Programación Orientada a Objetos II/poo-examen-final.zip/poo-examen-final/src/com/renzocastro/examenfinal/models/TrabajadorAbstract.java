package com.renzocastro.examenfinal.models;

public abstract class TrabajadorAbstract implements Trabajador {
  private String dni;
  private String nombreCompleto;
  private String direccion;
  private String areaDeTrabajo;

  public TrabajadorAbstract(String dni, String nombreCompleto, String direccion, String areaDeTrabajo) {
    this.dni = dni;
    this.nombreCompleto = nombreCompleto;
    this.direccion = direccion;
    this.areaDeTrabajo = areaDeTrabajo;
  }

  public String getDni() {
    return dni;
  }

  public void setDni(String dni) {
    this.dni = dni;
  }

  public String getNombreCompleto() {
    return nombreCompleto;
  }

  public void setNombreCompleto(String nombreCompleto) {
    this.nombreCompleto = nombreCompleto;
  }

  public String getDireccion() {
    return direccion;
  }

  public void setDireccion(String direccion) {
    this.direccion = direccion;
  }

  public String getAreaDeTrabajo() {
    return areaDeTrabajo;
  }

  public void setAreaDeTrabajo(String areaDeTrabajo) {
    this.areaDeTrabajo = areaDeTrabajo;
  }

  public abstract double calcularSueldoFinal();
}
