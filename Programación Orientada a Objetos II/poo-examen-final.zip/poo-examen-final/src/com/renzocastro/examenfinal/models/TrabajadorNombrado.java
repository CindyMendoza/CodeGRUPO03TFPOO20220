package com.renzocastro.examenfinal.models;

import com.renzocastro.examenfinal.shared.enums.Categorizacion;

public class TrabajadorNombrado extends TrabajadorAbstract {
  private double sueldoBase;
  private Categorizacion categorizacion;

  public TrabajadorNombrado(
    String dni,
    String nombreCompleto,
    String direccion,
    String areaDeTrabajo,
    double sueldoBase,
    Categorizacion categorizacion
  ) {
    super(dni, nombreCompleto, direccion, areaDeTrabajo);
    this.sueldoBase = sueldoBase;
    this.categorizacion = categorizacion;
  }

  public double getSueldoBase() {
    return sueldoBase;
  }

  public void setSueldoBase(double sueldoBase) {
    this.sueldoBase = sueldoBase;
  }

  public Categorizacion getCategorizacion() {
    return categorizacion;
  }

  public void setCategorizacion(Categorizacion categorizacion) {
    this.categorizacion = categorizacion;
  }

  @Override
  public double calcularSueldoFinal() {
    return this.getSueldoBase() + this.getCategorizacion().getBono();
  }

  @Override
  public String toString() {
    return "TrabajadorNombrado{" +
      "DNI='" + this.getDni() + '\'' +
      ", Nombre completo='" + this.getNombreCompleto() + '\'' +
      ", Direccion='" + this.getDireccion() + '\'' +
      ", Área de trabajo='" + this.getAreaDeTrabajo() + '\'' +
      ", Sueldo base=" + this.getSueldoBase() +
      ", Categorización=" + this.getCategorizacion() +
      ", Sueldo final=" + this.calcularSueldoFinal() +
      '}';
  }
}
