package com.renzocastro.examenfinal.models;

public interface Trabajador {
  String getDni();
  void setDni(String dni);

  String getNombreCompleto();
  void setNombreCompleto(String nombreCompleto);

  String getDireccion();
  void setDireccion(String direccion);

  String getAreaDeTrabajo();
  void setAreaDeTrabajo(String areaDeTrabajo);

  double calcularSueldoFinal();
}
