package com.renzocastro.examenfinal.models;

import com.renzocastro.examenfinal.shared.Utils;

public class TrabajadorDestacado extends TrabajadorAbstract {
  private double sueldoBase;
  private double porcentajeParticipacion;

  public TrabajadorDestacado(String dni, String nombreCompleto, String direccion, String areaDeTrabajo, double sueldoBase, double porcentajeParticipacion) {
    super(dni, nombreCompleto, direccion, areaDeTrabajo);
    this.sueldoBase = sueldoBase;
    this.porcentajeParticipacion = porcentajeParticipacion;
  }

  public double getSueldoBase() {
    return sueldoBase;
  }

  public void setSueldoBase(double sueldoBase) {
    this.sueldoBase = sueldoBase;
  }

  public double getPorcentajeParticipacion() {
    return porcentajeParticipacion;
  }

  public void setPorcentajeParticipacion(double porcentajeParticipacion) {
    this.porcentajeParticipacion = porcentajeParticipacion;
  }

  @Override
  public double calcularSueldoFinal() {
    return this.getSueldoBase() + ((this.getPorcentajeParticipacion() / 100) * Utils.getUtilidadesProyectadas());
  }

  @Override
  public String toString() {
    return "TrabajadorDestacado{" +
      "DNI='" + this.getDni() + '\'' +
      ", Nombre completo='" + this.getNombreCompleto() + '\'' +
      ", Direccion='" + this.getDireccion() + '\'' +
      ", Área de trabajo='" + this.getAreaDeTrabajo() + '\'' +
      ", Sueldo base=" + this.getSueldoBase() +
      ", % participación=" + this.getPorcentajeParticipacion() +
      ", Sueldo final=" + this.calcularSueldoFinal() +
      '}';
  }
}
