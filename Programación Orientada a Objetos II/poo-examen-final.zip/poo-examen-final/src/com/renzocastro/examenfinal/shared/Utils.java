package com.renzocastro.examenfinal.shared;

public class Utils {
  private static double utilidadesProyectadas;

  public static double getUtilidadesProyectadas() {
    return utilidadesProyectadas;
  }

  public static void setUtilidadesProyectadas(double utilidadesProyectadas) {
    Utils.utilidadesProyectadas = utilidadesProyectadas;
  }
}
