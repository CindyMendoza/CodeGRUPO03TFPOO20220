package com.renzocastro.examenfinal.shared.enums;

public enum Categorizacion {
  A ("A", 5000.0),
  B ("B", 3500.0),
  C ("C", 2500.0),
  D ("D", 1500.0),
  E ("E", 0.0);


  private final double bono;
  private final String tipo;

  Categorizacion(String tipo, double bono) {
    this.tipo = tipo;
    this.bono = bono;
  }

  public double getBono() {
    return bono;
  }

  public String getTipo() {
    return tipo;
  }
}
