package com.renzocastro.examenfinal.modules.empresa;

import com.renzocastro.examenfinal.models.Trabajador;

import java.util.List;

public class EmpresaController {
  private final List<Trabajador> _modelo;
  private final EmpresaView _vista;

  public EmpresaController(EmpresaView vista, List<Trabajador> modelo) {
    this._vista = vista;
    this._modelo = modelo;
  }

  public void listarTrabajadores() {
    this._vista.listarTrabajadores(this._modelo);
  }

  public void mostrarPagoTotalATrabajadoresTemporales() {
    this._vista.mostrarPagoTotalATrabajadoresTemporales(this._modelo);
  }

}
