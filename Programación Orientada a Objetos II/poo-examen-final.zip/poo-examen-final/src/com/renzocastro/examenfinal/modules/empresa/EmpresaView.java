package com.renzocastro.examenfinal.modules.empresa;

import com.renzocastro.examenfinal.models.Trabajador;
import com.renzocastro.examenfinal.models.TrabajadorTemporal;

import java.util.List;

public class EmpresaView {
  public void listarTrabajadores(List<Trabajador> trabajadores) {
    System.out.println();
    System.out.println("LISTADO DE TRABAJADORES");

    for (Trabajador trabajador: trabajadores) {
      System.out.println(trabajador);
    }

    System.out.println();
  }

  public void mostrarPagoTotalATrabajadoresTemporales(List<Trabajador> trabajadores) {
    double pagoTotal = this.obtenerPagoTotalATrabajadoresTemporales(trabajadores);

    System.out.println("La empresa paga a los trabajadores temporales: " + pagoTotal);
    System.out.println();
  }

  private double obtenerPagoTotalATrabajadoresTemporales(List<Trabajador> trabajadores) {
    double pagoTotal = 0.0;

    for (Trabajador trabajador: trabajadores) {
      if (trabajador instanceof TrabajadorTemporal) {
        pagoTotal += trabajador.calcularSueldoFinal();
      }
    }

    return pagoTotal;
  }
}
