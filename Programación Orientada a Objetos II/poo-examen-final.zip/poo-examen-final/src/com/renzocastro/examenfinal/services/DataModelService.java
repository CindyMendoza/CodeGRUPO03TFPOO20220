package com.renzocastro.examenfinal.services;

import com.renzocastro.examenfinal.models.Trabajador;
import com.renzocastro.examenfinal.models.TrabajadorDestacado;
import com.renzocastro.examenfinal.models.TrabajadorNombrado;
import com.renzocastro.examenfinal.models.TrabajadorTemporal;
import com.renzocastro.examenfinal.shared.enums.Categorizacion;
import com.renzocastro.examenfinal.shared.exceptions.DataModelException;

import java.util.ArrayList;
import java.util.List;

public class DataModelService {

  private List<Trabajador> _trabajadores;

  public DataModelService() {
    this._trabajadores = new ArrayList<>();
  }

  public void addTrabajador(Trabajador trabajador) throws DataModelException {
    boolean yaExiste = false;

    for (int i = 0; i < this._trabajadores.size(); i++) {
      if (trabajador.getDni().equals(this._trabajadores.get(i).getDni())) {
        yaExiste = true;
        break;
      }
    }

    if (yaExiste) {
      throw new DataModelException("El DNI del trabajador ya se encuentra registrado");
    } else {
      this._trabajadores.add(trabajador);
    }
  }

  public List<Trabajador> getTrabajadores() {
    return this._trabajadores;
  }
}
