package Override;

public class Estudiante {
    private String codigo;
    private String nombres;


    public Estudiante(String codigo, String nombres) {
        this.codigo = codigo;
        this.nombres = nombres;
    }

    public Estudiante() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    @Override
    public String toString(){
        return "Código de alumno = " + codigo + " , nombres = " + nombres;
    }
}
