package Override;

public class Main {
    public static void main(String[] args) {
        Estudiante e1 = new Estudiante("20221234", "Juan López");
        Estudiante e2 = new Estudiante("20229876", "Sara García");

        System.out.println(e1);
        //Lo siguiente es otra forma de hacerlo.
        //System.out.println("DNI = " + e1.getCodigo() + ", nombres = " + e1.getNombres());
        System.out.println(e2);
        //toString es un método de la clase Object
        //Retorna una cadena que representa a un objeto

    }
}
