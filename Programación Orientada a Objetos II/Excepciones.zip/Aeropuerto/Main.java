package Aeropuerto;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        //B, C
        Aerolinea aerolinea = new Aerolinea();

        Avion avion1 = new Avion("Boeing 747", 1, "A");
        Avion avion2 = new Avion("Airbus 329", 1, "A");

        avion1.registrarAsiento(20, "A");
        avion1.registrarAsiento(30, "B");

        avion2.registrarAsiento(20, "C");
        avion2.registrarAsiento(25, "D");

        aerolinea.registrarVuelo("XYZ123", "Lima", "Tumbes");
        aerolinea.asignarAvion("XYZ123", avion1);

        aerolinea.registrarVuelo("ABC789", "Tacna", "Ancash", avion2);

        //Mostrar los vuelos registrados
        System.out.println("Vuelos registrados:");
        List<Vuelo> vuelosRegistrados = aerolinea.getVuelos();
        for(Vuelo vuelo:vuelosRegistrados){
            System.out.println(vuelo);
        }

        //C: Vuelos por modelo de avión
        System.out.println("Busqueda por modelo de Avión: Boeing 747");
        List<Vuelo> vuelosModelo1 = new ArrayList<>();
        try{
            vuelosModelo1 = aerolinea.mostrarListaVuelosModeloAvion("Boeing 747");
        }
        catch (ModeloAvionInvalidoException e){
            System.out.println(e.getMessage());
        }

        for(Vuelo vuelo:vuelosModelo1){
            System.out.println(vuelo);
        }

        //D: Búsqueda de modelo de avión que no existe
        System.out.println("Búsqueda por modelo de Avión que no existe: Boeing 777");
        List<Vuelo> vuelosModelo2 = new ArrayList<>();
        try{
            vuelosModelo2 = aerolinea.mostrarListaVuelosModeloAvion("Boeing 777");
        }
        catch (ModeloAvionInvalidoException e){
            System.out.println(e.getMessage());
        }

        for(Vuelo vuelo:vuelosModelo2){
            System.out.println(vuelo);
        }
    }
}
