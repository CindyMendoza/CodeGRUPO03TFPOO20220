package Aeropuerto;

public class ModeloAvionInvalidoException extends Exception{

    @Override
    public String getMessage(){
        return "Modelo de avión inválido.";
    }
}
