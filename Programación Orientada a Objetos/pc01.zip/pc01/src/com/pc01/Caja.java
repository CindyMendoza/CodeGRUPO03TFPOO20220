package com.pc01;

import java.util.ArrayList;
import java.util.List;

public class Caja {
    private List<Producto> arregloProductos;

    public Caja() {
        this.arregloProductos = new ArrayList<>();
    }
    public void RegistrarProducto(Producto producto){
            this.arregloProductos.add(producto);

    }
    public List<Producto> ListarProductos() {
        return arregloProductos;
    }
    public void CalcularValorTotal(Producto producto){
        this.arregloProductos.add(producto);

    }
    public Double CalcularValorTotal(){
        Double suma = 0.0;
        for(Producto p: this.arregloProductos){
            suma+=p.calcularValor();
        }
        return suma;
    }
    public void setArregloProductos(List<Producto> arregloProductos) {
        this.arregloProductos = arregloProductos;
    }
}
