package com.pc01;

public class Main {

    public static void main(String[] args) {
        Lacteo lacteo1 = new Lacteo("L001", "leche",3.0,"Laive",50);
        Lacteo lacteo2 = new Lacteo("L002", "leche Chocolatada",7.0,"Laive",500);
        Fruta fruta1 = new Fruta("F001", "pera",1.5,10,true);
        Fruta fruta2 = new Fruta("F001", "Palta",3.5,5,false);
        Caja caja01 = new Caja();
        System.out.println("--------- Registrando productos -----------");
        caja01.RegistrarProducto(lacteo1);
        caja01.RegistrarProducto(lacteo2);
        caja01.RegistrarProducto(fruta1);
        caja01.RegistrarProducto(fruta2);
        System.out.println("--------- Listado de productos -----------");
        System.out.println(caja01.ListarProductos());
        System.out.println("--------- Calcular valor total -----------");
        System.out.println(caja01.CalcularValorTotal());
    }
}
