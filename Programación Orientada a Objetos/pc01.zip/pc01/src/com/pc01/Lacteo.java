package com.pc01;

public class Lacteo extends Producto{
    private String marca;
    private double mL;

    public Lacteo(String codigo, String nombre, Double precio, String marca, double mL) {
        super(codigo, nombre, precio);
        this.marca = marca;
        this.mL = mL;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getmL() {
        return mL;
    }

    public void setmL(double mL) {
        this.mL = mL;
    }
    @Override
    public String toString() {
        return "Lacteo{" +
                "marca='" + marca + '\'' +
                ", mL=" + mL +
                "} " + super.toString();
    }
    @Override
    public Double calcularValor() {
        if(this.mL>100){
            return this.getPrecio();
        }else{
            return Double.valueOf(0);
        }

    }
}
