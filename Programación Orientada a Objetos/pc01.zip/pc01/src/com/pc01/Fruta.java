package com.pc01;

public class Fruta extends Producto{
    private Integer cantidad;
    private Boolean esDulce;

    public Fruta(String codigo, String nombre, Double precio, Integer cantidad, Boolean esDulce) {
        super(codigo, nombre, precio);
        this.cantidad = cantidad;
        this.esDulce = esDulce;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Boolean getEsDulce() {
        return esDulce;
    }

    public void setEsDulce(Boolean esDulce) {
        this.esDulce = esDulce;
    }

    @Override
    public String toString() {
        return "Fruta{" +
                "cantidad=" + cantidad +
                ", esDulce=" + esDulce +
                "} " + super.toString();
    }

    @Override
    public Double calcularValor() {
        return this.getPrecio()*this.getCantidad();
    }
}
