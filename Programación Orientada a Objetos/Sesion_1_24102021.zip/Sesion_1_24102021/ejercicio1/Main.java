package ejercicio1;

public class Main {

    public static void main(String[] args) {

        Alumno alumnoA = new Alumno("pcsijost", "Jose Torres", 55, 95);
        System.out.println(alumnoA);
        System.out.println(alumnoA.obtenerEstado());


    }
}
